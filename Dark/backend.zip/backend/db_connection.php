<?php
$host = 'localhost';
$dbname = 'kamco_db';
$username = 'kamco_db';
$password = ']CuXFJ&UFJ$z';

try {
    // First try connecting to existing database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // If database doesn't exist, create it
    try {
        $pdo = new PDO("mysql:host=$host;charset=utf8", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        
    } catch (PDOException $e) {
        die("Database setup failed: " . $e->getMessage());
    }
}
?>
