<?php
header('Content-Type: application/json');
require '/home/pmzc27wuvsg8/public_html/main/backend/db_connection.php'; // full path (not recommended for portability)

try {
    // Fetch all blogs
    $query =$pdo->prepare("SELECT * FROM blogs");
    $query->execute();
    $blogs = $query->fetchAll(PDO::FETCH_ASSOC);

    // Fetch images for each blog
    foreach ($blogs as &$blog) {
        $imgQuery =$pdo->prepare("SELECT image FROM blogs WHERE id = :id");
        $imgQuery->bindParam(':id', $blog['id'], PDO::PARAM_INT);
        $imgQuery->execute();
        $images = $imgQuery->fetchAll(PDO::FETCH_COLUMN);
        $blog['images'] = $images; // Add images to each blog
    }

    echo json_encode($blogs);
} catch (PDOException $e) {
    echo json_encode(["error" => "Database error: " . $e->getMessage()]);
}
